<?php
/** WordPress retains its native 404 status; render with the common shell. */
ob_start();
get_template_part( 'template-parts/pages/not-found' );
$content = ob_get_clean();
$sections = array( array(
    'layout' => 'single', 'tone' => 'paper', 'number' => '01', 'label' => 'УПС',
    'content' => $content,
) );
get_header();
?>
</section>
<main class="mcp-inner-main">
<?php mcp_render_internal_sections( $sections ); ?>
</main>
<?php get_footer( null, mcp_footer_args( $sections ) ); ?>
