# Техническая основа MCP — 23 октября 2026

Проверена репозиторная тема после микроправки 404 (`c55b95f`). Визуальные CSS,
header/footer, тексты, изображения и геометрия не изменены. Production не
подключался; на madfox.com.ru выполнены только чтения.

## Фактическое состояние madfox.com.ru

Authenticated read: WordPress 7.1.3, PHP 8.3.36. Активна `mcp-minimal-child`,
parent Martanda. **Серверный `mcp-minimal-child-wpvibe-draft` отстаёт от Git**:

- Его functions.php не подключает новые About/404 CSS; 404.php — прежняя
  текстовая версия без иллюстрации. Новые About data и illustrations отсутствуют.
- Сохранены canvas-test.css, большой style.css с Geologica @import, parts/*.html,
  старые templates/*.html и дополнительные mcp-clients/clock/footer/section-numbering.js.
  Наличие файла не означает, что он подключён в новой PHP-оболочке.
- WP-CLI сообщает активные Martanda Premium, WP Reset, WP Super Cache, WPVibe.
  Elementor установлен, но отсутствует в полученном списке активных плагинов.

Серверные файлы, плагины, активная тема, БД и cache не изменены. Смешанный
серверный draft автоматически не перезаписывался, старые файлы не удалялись.

## Единая система текущей темы

- `header.php` / `footer.php` → `template-parts/site/`: одна оболочка, canvas,
  header, footer, crop marks. Контакты и маркеры — `template-parts/components/`.
- `assets/css/tokens.css`, `site.css`, `page.css`, `internal.css`: общая сетка,
  оси, типографика, paper/paper-alt, responsive. Page-specific CSS изолирован.
- Geologica подключается один раз через `mcp-fonts` в functions.php.
- `site.js` — общий legal/crop alignment; `home.js` — только Home carousel.
  About использует тот же компонент клиентов с CSS двух рядов, без второго JS.
- `inc/navigation.php`: native/fallback menu, логотип → Home, Контакты → #contacts.
- `inc/routes.php`: defaults и footer numbering; explicit meta/editor content
  приоритетны. Активация не пишет в БД. Bootstrap только явной WP-CLI командой.

| Страница | Общий путь сборки | Состояние |
|---|---|---|
| Home | front-page.php → template-parts/home/ | Принятая Главная |
| About | templates/internal.php → data/about.php | Текущая согласованная сборка |
| Services / Products | templates/internal.php | Заготовки Pages |
| Artwork Requirements | templates/internal.php | Заготовка Page |
| Useful / Blog | templates/internal.php | Заготовка Page, page_for_posts=0 |
| Single Article | single.php → templates/internal.php | Общая оболочка/editor content |
| Payment & Delivery | internal → data/payment-delivery.php | Принятая страница |
| Privacy Policy | internal → data/privacy-policy.php / explicit meta | Принятая политика |
| Requisites | internal → data/requisites.php | Принятая страница |
| Sitemap | internal → data/sitemap.php | Принятая карта сайта |
| 404 | 404.php → template-parts/pages/not-found.php | Native HTTP 404 |

В 404 используется только `assets/images/illustrations/mcp-404-illustration-final.webp`.
Старого mcp-404-illustration.webp в исходной теме нет. Тон/положение сохранены.
Новые секции строятся через internal hero/single/split/wide; новый header/footer
не копируется. Blog feed и дизайн статьи заранее не придумываются.

## Что исправлено

- Версия CSS/JS в URL теперь зависит от SHA-256 файла, а не только от 0.5.0:
  микроправки draft обновляют URL ресурса. Уже сохранённый page-cache HTML это
  автоматически не очищает — его очистка остаётся этапом deployment.
- template_include явно выбирает single.php/home.php, предотвращая подхват
  старых block/parent templates для статей и будущего posts index.
- Page defaults не подменяют Post с совпадающим slug.
- page-content.php сохранён как совместимый alias route-content.php: один
  HTML renderer editor content вместо двух копий.
- site.js безопасно завершает работу при отсутствии canvas/legal/mark.
- Актуализированы WP scaffold/Blog tests, добавлен tests/theme-foundation.php:
  13 route/template/resource contracts, cache invalidation и текущий 404 asset.
- FILE_TREE.txt обновлён под актуальную структуру.

## Проверки и ограничения

- PHP lint всех файлов темы; resource/template contracts; footer numbering.
- 77 static route/viewport проверок: 1920/1440/1280/1024/768/390/320. Общий shell,
  Geologica, contact anchor, номера footer, legal/crop, отсутствие нового main overflow.
- 14 screenshot-сравнений Главной и 7 nested Pages 404 проверок.
- Disposable local WP: scaffold idempotence, сохранение существующих данных,
  пустая Blog Page и article через общий shell. Тестовые Posts удалены,
  настройки восстановлены. Local parent — Twenty Twenty-One; это не полный
  регресс новой сборки на Martanda настоящего staging.
- Ранее известное mobile-переполнение замороженного header не переделывалось.

## Осталось / рискованные изменения — не выполнялись

1. Сверить и загрузить текущий пакет в server draft, сохранив прежнюю тему/данные.
   Перед этим проверить mcp_image_urls: Media overrides могут подменять assets.
2. В server preview проверить загружаемые ресурсы Martanda Premium, block
   templates, Custom CSS и сохранённый Elementor content. Затем решать, какие
   legacy-файлы/хуки исключать. Не удалять плагины и старые данные автоматически.
3. Публикация draft, page-cache purge и полный публичный регресс на Martanda —
   отдельный этап. В текущем проходе сервер не изменён.
4. Наполнять Services/Products/Artwork/Blog/Single после утверждения страниц.
   Search/category/archive пока не утверждены и могут использовать parent fallback.
5. site.css сохраняет исторический каскад принятых правил, включая перекрытые
   координаты. Массовую консолидацию не делать без отдельного pixel parity прохода.
6. data/services.json, tools/about-experimental.* и illustrations/library/ не
   подключены к маршрутам. Сохранены как архив/исходные материалы, не удалены.
7. CLI static renderer имеет свой adapter подключения ресурсов. При добавлении
   page-specific CSS поддерживать соответствие WP enqueue браузерными проверками.
