  <section class="band band-4">
    <?php get_template_part( 'template-parts/components/section-marker', null, array( 'number' => mcp_home_section_number( 'clients' ), 'label' => 'КЛИЕНТЫ' ) ); ?>
    <div class="section04-inner">
      <div class="section04-intro">
        <h2 class="section04-title">Нам<br>доверяют</h2>
      </div>
<?php get_template_part( 'template-parts/components/client-carousel' ); ?>
  </section>
