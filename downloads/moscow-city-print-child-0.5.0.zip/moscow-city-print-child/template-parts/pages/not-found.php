<?php /** Body only. Shared internal section, marker, header and footer wrap it. */ ?>
<div class="mcp-not-found-intro">
    <div class="mcp-not-found-left">
        <div class="mcp-not-found-copy">
            <h1 class="mcp-page-title">Страница не найдена</h1>
            <p>К сожалению, такой страницы не существует.<br>Она могла быть удалена или её адрес изменился.</p>
            <p><a href="<?php echo esc_url( home_url( '/' ) ); ?>">На главную →</a></p>
        </div>
        <div class="mcp-not-found-links">
            <h2>Возможно, вы ищете:</h2>
            <ol>
            <?php $index = 0; foreach ( array( 'services' => 'Услуги', 'products' => 'Продукция', 'artwork-requirements' => 'Требования к макетам', 'payment-delivery' => 'Оплата и доставка', 'blog' => 'Полезное о печати' ) as $slug => $title ) : ?>
                <li><a href="<?php echo esc_url( mcp_page_url( $slug ) ); ?>"><span class="mcp-not-found-index"><?php echo sprintf( '%02d', ++$index ); ?></span><span><?php echo esc_html( $title ); ?></span><span aria-hidden="true">→</span></a></li>
            <?php endforeach; ?>
            </ol>
        </div>
    </div>
    <div class="mcp-not-found-art">
        <img src="<?php echo esc_url( mcp_asset_url( 'images/illustrations/mcp-404-illustration-final.webp' ) ); ?>" width="1530" height="1028" alt="404" decoding="async">
    </div>
</div>
