      <div class="clients-wrap" aria-label="Клиенты">
        <button type="button" class="client-nav prev clients-prev" aria-label="Предыдущие клиенты">←</button>
        <button type="button" class="client-nav next clients-next" aria-label="Следующие клиенты">→</button>
        <div class="clients-track">

          <div class="client"><img class="client-logo" src="<?php echo esc_url( mcp_asset_url( 'images/clients/client-01.png' ) ); ?>" alt="Huawei"></div>
          <div class="client"><img class="client-logo karavaevy" src="<?php echo esc_url( mcp_asset_url( 'images/clients/client-02.png' ) ); ?>" alt="Братья Караваевы"></div>
          <div class="client"><img class="client-logo" src="<?php echo esc_url( mcp_asset_url( 'images/clients/client-03.png' ) ); ?>" alt="R7"></div>
          <div class="client"><img class="client-logo" src="<?php echo esc_url( mcp_asset_url( 'images/clients/client-04.png' ) ); ?>" alt="Empire"></div>

          <div class="client"><img class="client-logo" src="<?php echo esc_url( mcp_asset_url( 'images/clients/client-05.png' ) ); ?>" alt="Торговый дом Пластик"></div>
          <div class="client"><img class="client-logo" src="<?php echo esc_url( mcp_asset_url( 'images/clients/client-06.png' ) ); ?>" alt="АльфаХимПром"></div>
          <div class="client"><img class="client-logo" src="<?php echo esc_url( mcp_asset_url( 'images/clients/client-07.png' ) ); ?>" alt="One Factor"></div>
          <div class="client"><img class="client-logo" src="<?php echo esc_url( mcp_asset_url( 'images/clients/client-08.png' ) ); ?>" alt="TrendLaw"></div>
      </div>
    </div>
