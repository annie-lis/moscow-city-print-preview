    <header class="header">
      <a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="Moscow City Print — Главная"><img src="<?php echo esc_url( mcp_asset_url( 'images/logo.png' ) ); ?>" alt="Типография Москва Сити Принт"></a>
      <div class="header-right">
        <div class="status"><span>12:04</span><span>·</span><span>Работаем</span></div>
        <nav class="nav">
<?php foreach ( mcp_primary_menu_items() as $item ) : ?>
          <a href="<?php echo esc_url( $item['url'] ); ?>"<?php echo $item['current'] ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $item['label'] ); ?></a>
<?php endforeach; ?>
        </nav>
      </div>
    </header>
