<?php /** Universal article: optional lead, natural content flow, no required image/sections. */ ?>
<article class="mcp-article">
    <nav class="mcp-article-breadcrumbs" aria-label="Хлебные крошки">
    <?php foreach ( $args['breadcrumbs'] as $i => $crumb ) : ?>
        <?php if ( $i ) : ?><span aria-hidden="true">/</span><?php endif; ?>
        <?php if ( $i === count( $args['breadcrumbs'] ) - 1 ) : ?><span aria-current="page"><?php echo esc_html( $crumb['title'] ); ?></span>
        <?php else : ?><a href="<?php echo esc_url( $crumb['url'] ); ?>"><?php echo esc_html( $crumb['title'] ); ?></a><?php endif; ?>
    <?php endforeach; ?>
    </nav>
    <header class="mcp-article-header">
        <div class="mcp-article-meta"><time datetime="<?php echo esc_attr( $args['iso'] ); ?>"><?php echo esc_html( $args['date'] ); ?></time><span><?php echo esc_html( $args['topic']['name'] ); ?></span></div>
        <h1 class="mcp-page-title"><?php echo esc_html( $args['title'] ); ?></h1>
        <?php if ( $args['modified'] !== $args['iso'] ) : ?><p class="mcp-article-updated">Обновлено <time datetime="<?php echo esc_attr( $args['modified'] ); ?>"><?php echo esc_html( $args['modified_label'] ?? substr( $args['modified'], 0, 10 ) ); ?></time></p><?php endif; ?>
        <?php if ( $args['lead'] !== '' ) : ?><div class="mcp-page-copy mcp-article-lead"><?php echo wp_kses_post( $args['lead'] ); ?></div><?php endif; ?>
    </header>
    <div class="mcp-page-copy mcp-article-content"><?php echo $args['content']; // Native the_content filters already applied; preserve supported editor blocks. ?></div>
</article>
<nav class="mcp-article-navigation" aria-label="Навигация по статьям">
    <div><?php if ( $args['previous'] ) : ?><a rel="prev" href="<?php echo esc_url( $args['previous']['url'] ); ?>" aria-label="<?php echo esc_attr( 'Предыдущая статья: ' . $args['previous']['title'] ); ?>">← Предыдущая статья</a><?php endif; ?></div>
    <a class="mcp-article-all" href="<?php echo esc_url( mcp_page_url( 'blog' ) ); ?>">Все статьи</a>
    <div><?php if ( $args['next'] ) : ?><a rel="next" href="<?php echo esc_url( $args['next']['url'] ); ?>" aria-label="<?php echo esc_attr( 'Следующая статья: ' . $args['next']['title'] ); ?>">Следующая статья →</a><?php endif; ?></div>
</nav>
