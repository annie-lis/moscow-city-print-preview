<?php
/** Shared catalog presentation; data comes from WP_Query or preview-only fixtures. */
$state = $args['state'];
?>
<form class="mcp-blog-search" role="search" action="<?php echo esc_url( mcp_page_url( 'blog' ) ); ?>" method="get">
    <svg aria-hidden="true" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1"><circle cx="10" cy="10" r="6.5"/><path d="m15 15 6 6"/></svg>
    <label class="mcp-blog-search-label" for="mcp-blog-search">Поиск по блогу</label>
    <input id="mcp-blog-search" type="search" name="blog_search" placeholder="Поиск по блогу" value="<?php echo esc_attr( $state['search'] ); ?>">
    <?php if ( $state['category'] !== '' ) : ?><input type="hidden" name="blog_category" value="<?php echo esc_attr( $state['category'] ); ?>"><?php endif; ?>
    <button type="submit" aria-label="Найти статьи">→</button>
</form>
<nav class="mcp-blog-filters" aria-label="Рубрики блога">
<?php foreach ( array_merge( array( '' => 'Все' ), mcp_blog_topics() ) as $slug => $label ) : ?>
    <a href="<?php echo esc_url( mcp_blog_link( array_merge( $state, array( 'category' => $slug, 'page' => 1 ) ) ) ); ?>"<?php echo $slug === $state['category'] ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $label ); ?></a>
<?php endforeach; ?>
</nav>
<?php if ( $args['items'] ) : ?>
<ol class="mcp-blog-list" start="<?php echo (int) ( ( $state['page'] - 1 ) * $args['per_page'] + 1 ); ?>">
<?php foreach ( $args['items'] as $i => $item ) : ?>
    <li><a class="mcp-blog-row" href="<?php echo esc_url( $item['url'] ); ?>">
        <span class="mcp-blog-index"><?php echo esc_html( sprintf( '%02d', ( $state['page'] - 1 ) * $args['per_page'] + $i + 1 ) ); ?></span>
        <span class="mcp-blog-meta"><time datetime="<?php echo esc_attr( $item['iso'] ); ?>"><?php echo esc_html( $item['date'] ); ?></time><span><?php echo esc_html( $item['topic']['name'] ); ?></span></span>
        <span class="mcp-blog-row-title"><?php echo esc_html( $item['title'] ); ?></span><span class="mcp-blog-arrow" aria-hidden="true">→</span>
    </a></li>
<?php endforeach; ?>
</ol>
<?php else : ?>
<p class="mcp-blog-empty" role="status"><?php echo $args['total'] > 0 && $state['page'] > 1 ? 'На этой странице нет материалов.' : ( $state['search'] !== '' || $state['category'] !== '' ? 'Материалы не найдены.' : 'Публикаций пока нет.' ); ?></p>
<?php endif; ?>
<?php if ( $args['pages'] > 1 ) : ?>
<nav class="mcp-blog-pagination" aria-label="Страницы блога">
<?php
$visible = array_unique( array_filter( array( 1, $state['page'] - 1, $state['page'], $state['page'] + 1, $args['pages'] ), fn( $p ) => $p >= 1 && $p <= $args['pages'] ) );
sort( $visible ); $last = 0;
foreach ( $visible as $page ) :
    if ( $last && $page > $last + 1 ) { echo '<span aria-hidden="true">…</span>'; }
?>
    <a href="<?php echo esc_url( mcp_blog_link( array_merge( $state, array( 'page' => $page ) ) ) ); ?>"<?php echo $page === $state['page'] ? ' aria-current="page"' : ''; ?> aria-label="<?php echo esc_attr( 'Страница ' . $page ); ?>"><?php echo (int) $page; ?></a>
<?php $last = $page; endforeach; ?>
<?php if ( $state['page'] < $args['pages'] ) : ?><a rel="next" aria-label="Следующая страница" href="<?php echo esc_url( mcp_blog_link( array_merge( $state, array( 'page' => $state['page'] + 1 ) ) ) ); ?>">→</a><?php endif; ?>
</nav>
<?php endif; ?>
<?php if ( ! empty( $args['archive_url'] ) ) : ?><p class="mcp-blog-archive"><a href="<?php echo esc_url( $args['archive_url'] ); ?>">Из старого блога →</a></p><?php endif; ?>
