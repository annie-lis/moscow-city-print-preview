<?php
/** Text/item content, using existing page typography and Home step components. */
if ( ! empty( $args['client_carousel'] ) ) {
    $copy_args = $args;
    unset( $copy_args['client_carousel'] );
    echo '<div class="mcp-content-with-clients"><div class="mcp-carousel-copy">';
    get_template_part( 'template-parts/internal/content', null, $copy_args );
    echo '</div>';
    get_template_part( 'template-parts/components/client-carousel' );
    echo '</div>';
    return;
}
$heading = isset( $args['heading'] ) && in_array( $args['heading'], array( 'h1', 'h2', 'h3' ), true ) ? $args['heading'] : 'h2';
if ( ! empty( $args['title'] ) ) : ?>
<<?php echo $heading; ?> class="mcp-page-title"><?php echo esc_html( $args['title'] ); ?></<?php echo $heading; ?>>
<?php endif; ?>
<?php if ( ! empty( $args['content'] ) ) : ?>
<div class="mcp-page-copy"><?php echo wp_kses_post( $args['content'] ); ?></div>
<?php endif; ?>
<?php if ( ! empty( $args['items'] ) && is_array( $args['items'] ) ) : ?>
<div class="steps mcp-inner-sequence">
    <?php foreach ( $args['items'] as $item ) : if ( ! is_array( $item ) ) { continue; } ?>
    <article class="step">
        <div class="step-num"><?php echo esc_html( $item['number'] ?? '' ); ?></div>
        <div class="card-content">
            <h3><?php echo esc_html( $item['title'] ?? '' ); ?></h3>
            <?php if ( ! empty( $item['text'] ) ) : ?><p><?php echo esc_html( $item['text'] ); ?></p><?php endif; ?>
            <?php if ( ! empty( $item['content'] ) ) : ?><div class="mcp-page-copy"><?php echo wp_kses_post( $item['content'] ); ?></div><?php endif; ?>
        </div>
    </article>
    <?php endforeach; ?>
</div>
<?php endif; ?>
