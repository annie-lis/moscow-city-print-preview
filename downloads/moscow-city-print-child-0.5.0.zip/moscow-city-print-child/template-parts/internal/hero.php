<?php /** Reusable unnumbered, centered hero for internal pages. */ ?>
<section class="mcp-inner-hero mcp-inner-section--<?php echo esc_attr( $args['tone'] ); ?>">
    <div class="mcp-inner-hero-content">
        <?php get_template_part( 'template-parts/internal/content', null, $args ); ?>
    </div>
</section>
