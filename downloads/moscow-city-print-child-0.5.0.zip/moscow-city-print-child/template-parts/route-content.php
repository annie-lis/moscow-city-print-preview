<?php
/** Editor content for pages without structured internal sections. */
while ( have_posts() ) : the_post(); ?>
<article class="mcp-page-content">
  <h1 class="mcp-page-title"><?php the_title(); ?></h1>
  <div class="mcp-page-copy">
  <?php
  if ( trim( (string) get_post_field( 'post_content', get_queried_object_id() ) ) !== '' ) {
      the_content();
  }
  ?>
  </div>
</article>
<?php endwhile; ?>
