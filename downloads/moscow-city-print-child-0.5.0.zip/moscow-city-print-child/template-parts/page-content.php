<?php
/** Compatibility entry point; keep editor output in one shared component. */
get_template_part( 'template-parts/route-content' );
