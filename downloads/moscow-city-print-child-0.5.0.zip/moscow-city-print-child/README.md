# Moscow City Print — промежуточная дочерняя тема 0.5.0

Тестовый WordPress: **https://madfox.com.ru/**. Родитель: **Martanda 2.0.2**,
как у активной темы стенда. Production moscowcityprint.ru не изменяется.

Эталон Главной: принятая версия `54c52f4:work/main_hero_preview.html`, с последующими
согласованными правками навигации. Общие CSS, размеры, сетка, Geologica, hero,
метки реза и компоненты принятых страниц сохранены. В footer добавлена только
запрошенная служебная ссылка «Карта сайта».

## Общие компоненты

- `header.php`, `footer.php` — единственная оболочка документа.
- `template-parts/site/` — header, footer, crop marks.
- `assets/css/tokens.css`, `site.css`, `page.css`, `internal.css` — общая система.
- `template-parts/components/` — секционные маркеры и контактные данные.
- `templates/internal.php`, `template-parts/internal/` — принятый универсальный
  шаблон: single / split / wide, без копий header/footer на страницах.
- `inc/navigation.php` — native WordPress menu `mcp-primary`, без новых обёрток.
- `inc/routes.php` — URL, defaults содержимого, карта сайта, номер footer.
- `inc/site-setup.php` — явный bootstrap WP-CLI; активация не пишет в БД.

Стили Martanda и его dynamic CSS отключены в общем `functions.php`, чтобы
родитель не менял принятый визуал. PHP-оболочка выбирается централизованно через
`template_include`, в том числе если от прежней темы остались block templates.

## Страницы

| Страница | Источник / шаблон |
|---|---|
| Главная | `front-page.php` → `template-parts/home/` |
| Реквизиты | `data/requisites.php` → общий internal |
| Оплата и доставка | `data/payment-delivery.php` → общий internal |
| Карта сайта | `data/sitemap.php` → общий internal |
| Политика конфиденциальности | `data/privacy-policy.php` → общий internal |
| 404 | `404.php` → те же внутренние компоненты; native HTTP 404 |
| О типографии | `data/about.php` → общий internal; пять секций, footer 06 |
| Услуги, Продукция | Обычные Pages, общий internal, пока только название |
| Требования к макетам, Полезное о печати | Такие же пустые Pages |

`/blog/` на этом этапе — обычная Page; `page_for_posts` должен быть 0.
About использует последнюю согласованную editorial-композицию и тексты из ТЗ.
Секции 02/03: текст, прозрачная иллюстрация, статистика/тезисы; 04: skyline справа.
05 переиспользует `template-parts/components/client-carousel.php` и `home.js`
Главной, без изменения её визуального результата. На mobile логотипы — сетка.
Page-specific CSS — `assets/css/about.css`, иллюстрации без изменений —
`assets/images/illustrations/`. CMYK-файл сохранён, в About не используется.
Исторический `data/services.json` не подключён как default.
Вакансии — прежний архивный preview; bootstrap не создаёт эту страницу на стенде.

Контакты находятся исключительно в `footer#contacts` текущей страницы.
Footer получает следующий номер после её последней секции: Home 04,
реквизиты/оплата 03, sitemap/privacy/404 02, пустые заготовки 01.

## Меню и изображения

Область меню: `mcp-primary` (Внешний вид → Меню). При отсутствии назначения
можно указать ID native menu в опции `mcp_primary_menu`; пустое меню использует
согласованные четыре ссылки fallback. Редактор может создать/назначить меню:
О типографии → Услуги → Продукция → custom link `#contacts`.
Логотип всегда ведёт на Главную.

PNG по умолчанию находятся в `assets/images/`. Для managed deployment через
WPVibe те же файлы импортированы в Media; опция `mcp_image_urls` сопоставляет
исходные пути оригинальным URL. Для hero выбран оригинал, а не автоматически
созданная WordPress scaled-копия. Геометрия изображений определяется прежним CSS.

## Сборка

```sh
php tools/render-static.php work/static-site --sync-work
php tools/render-static.php work/pages-export --pages-base=/moscow-city-print-preview/
python3 tools/package-theme.py
```

Команды выполняются от корня репозитория. ZIP самодостаточен по ресурсам темы,
но требует установленного родителя Martanda. PHP ≥8.0, WordPress ≥6.5.
Данные редактора и явные `_mcp_internal_sections` имеют приоритет над defaults.

Точный статус стенда и оставшиеся действия: [STAGING_STATUS.md](STAGING_STATUS.md).
Установка и откат: [DEPLOYMENT.md](DEPLOYMENT.md).
