<?php
/** Data-driven internal sections; no demo or page-specific content lives here. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function mcp_get_internal_sections( $post_id ) {
    $sections = get_post_meta( $post_id, '_mcp_internal_sections', true );
    $sections = apply_filters( 'mcp_internal_sections', is_array( $sections ) ? $sections : array(), $post_id );
    if ( ! is_array( $sections ) ) { return array(); }
    return array_values( array_filter( $sections, 'mcp_is_internal_section' ) );
}

function mcp_is_internal_section( $section ) {
    if ( ! is_array( $section ) || ! isset( $section['layout'] ) ) { return false; }
    if ( ! in_array( $section['layout'], array( 'hero', 'single', 'split', 'wide' ), true ) ) { return false; }
    if ( $section['layout'] === 'split' ) {
        return isset( $section['columns'] ) && is_array( $section['columns'] )
            && count( $section['columns'] ) === 2
            && isset( $section['columns'][0], $section['columns'][1] )
            && is_array( $section['columns'][0] ) && is_array( $section['columns'][1] );
    }
    return true;
}

function mcp_render_internal_sections( $sections ) {
    foreach ( $sections as $section ) {
        if ( ! mcp_is_internal_section( $section ) ) { continue; }
        $section['tone'] = isset( $section['tone'] ) && $section['tone'] === 'paper-alt' ? 'paper-alt' : 'paper';
        get_template_part( 'template-parts/internal/' . $section['layout'], null, $section );
    }
}
