<?php
/** Blog queries and presentation data. No content or taxonomy writes on activation. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function mcp_blog_topics() {
    return array( 'layouts' => 'Макеты', 'materials' => 'Материалы', 'technologies' => 'Технологии', 'production' => 'Производство' );
}
function mcp_blog_query_vars( $vars ) {
    return array_merge( $vars, array( 'blog_search', 'blog_category', 'blog_page' ) );
}
add_filter( 'query_vars', 'mcp_blog_query_vars' );

function mcp_blog_state() {
    $search = get_query_var( 'blog_search', '' );
    $category = get_query_var( 'blog_category', '' );
    $page = get_query_var( 'blog_page', 1 );
    $search = is_scalar( $search ) ? sanitize_text_field( (string) $search ) : '';
    $category = is_string( $category ) && isset( mcp_blog_topics()[ $category ] ) ? $category : '';
    return array( 'search' => $search, 'category' => $category, 'page' => is_scalar( $page ) ? max( 1, min( 10000, absint( $page ) ) ) : 1 );
}
function mcp_blog_link( $state = array() ) {
    $args = array();
    if ( ! empty( $state['search'] ) ) { $args['blog_search'] = $state['search']; }
    if ( ! empty( $state['category'] ) ) { $args['blog_category'] = $state['category']; }
    if ( ( $state['page'] ?? 1 ) > 1 ) { $args['blog_page'] = (int) $state['page']; }
    return $args ? add_query_arg( $args, mcp_page_url( 'blog' ) ) : mcp_page_url( 'blog' );
}
function mcp_post_topic( $post_id ) {
    $terms = get_the_category( $post_id );
    foreach ( $terms as $term ) {
        if ( isset( mcp_blog_topics()[ $term->slug ] ) ) { return array( 'slug' => $term->slug, 'name' => $term->name ); }
    }
    return $terms ? array( 'slug' => $terms[0]->slug, 'name' => $terms[0]->name ) : array( 'slug' => '', 'name' => '' );
}
function mcp_blog_data() {
    $state = mcp_blog_state();
    $args = array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 8,
        'paged' => $state['page'], 'ignore_sticky_posts' => true, 'orderby' => 'date', 'order' => 'DESC' );
    if ( $state['search'] !== '' ) { $args['s'] = $state['search']; }
    if ( $state['category'] !== '' ) { $args['category_name'] = $state['category']; }
    $query = new WP_Query( $args );
    $items = array();
    foreach ( $query->posts as $post ) {
        $items[] = array( 'title' => get_the_title( $post ), 'url' => get_permalink( $post ),
            'date' => get_the_date( 'd.m.Y', $post ), 'iso' => get_the_date( 'c', $post ),
            'topic' => mcp_post_topic( $post->ID ) );
    }
    return array( 'state' => $state, 'items' => $items, 'pages' => (int) $query->max_num_pages,
        'total' => (int) $query->found_posts, 'per_page' => 8,
        'archive_url' => apply_filters( 'mcp_blog_archive_url', '' ) );
}
function mcp_article_data( $post_id, $render_content = true ) {
    $post = get_post( $post_id );
    $topic = mcp_post_topic( $post_id );
    $content = $render_content ? apply_filters( 'the_content', $post->post_content ) : '';
    $description = trim( $post->post_excerpt ) !== '' ? $post->post_excerpt : $post->post_content;
    $description = preg_replace( '/\s+/u', ' ', wp_strip_all_tags( strip_shortcodes( $description ) ) );
    $breadcrumbs = array( array( 'title' => 'Блог', 'url' => mcp_page_url( 'blog' ) ) );
    if ( $topic['name'] !== '' ) {
        $url = isset( mcp_blog_topics()[ $topic['slug'] ] ) ? mcp_blog_link( array( 'category' => $topic['slug'] ) ) : mcp_page_url( 'blog' );
        $breadcrumbs[] = array( 'title' => $topic['name'], 'url' => $url );
    }
    $breadcrumbs[] = array( 'title' => get_the_title( $post_id ), 'url' => get_permalink( $post_id ) );
    $adjacent = array();
    foreach ( array( 'previous' => true, 'next' => false ) as $key => $previous ) {
        $other = get_adjacent_post( false, '', $previous, 'category' );
        $adjacent[ $key ] = $other ? array( 'title' => get_the_title( $other ), 'url' => get_permalink( $other ) ) : null;
    }
    return array( 'title' => get_the_title( $post_id ), 'content' => $content,
        'lead' => trim( $post->post_excerpt ) !== '' ? wpautop( wp_kses_post( $post->post_excerpt ) ) : '',
        'description' => wp_trim_words( $description, 32, '…' ), 'url' => get_permalink( $post_id ),
        'date' => get_the_date( 'd.m.Y', $post_id ), 'iso' => get_post_time( 'c', true, $post_id ),
        'modified' => get_post_modified_time( 'c', true, $post_id ), 'modified_label' => get_post_modified_time( 'd.m.Y', false, $post_id ), 'topic' => $topic,
        'author' => get_the_author_meta( 'display_name', $post->post_author ),
        'site_name' => get_bloginfo( 'name' ), 'home_url' => home_url( '/' ),
        'image' => get_the_post_thumbnail_url( $post_id, 'full' ) ?: '',
        'breadcrumbs' => $breadcrumbs, 'previous' => $adjacent['previous'], 'next' => $adjacent['next'] );
}
