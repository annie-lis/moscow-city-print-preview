<?php
/** Explicit, idempotent staging bootstrap. Activation never creates/overwrites pages. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function mcp_scaffold_pages() {
    $result = array();
    foreach ( mcp_site_routes() as $key => $route ) {
        // Historical vacancies preview is not part of this staging deployment.
        if ( $key === 'vacancies' ) { continue; }
        $slug = $key === 'home' ? 'home' : $route['slug'];
        $page = get_page_by_path( $slug );
        $created = ! $page;
        $id = $page ? $page->ID : wp_insert_post( array(
            'post_type' => 'page', 'post_status' => 'publish',
            'post_name' => $slug, 'post_title' => $route['title'],
        ), true );
        if ( is_wp_error( $id ) ) { return $id; }
        if ( $created ) {
            update_post_meta( $id, '_wp_page_template', 'templates/internal.php' );
        }
        $result[ $key ] = array( 'id' => $id, 'created' => $created, 'status' => get_post_status( $id ) );
    }
    return $result;
}

if ( defined( 'WP_CLI' ) && WP_CLI ) {
    WP_CLI::add_command( 'mcp scaffold', function ( $args, $assoc ) {
        WP_CLI::confirm( 'Create missing MCP pages on this WordPress installation?', $assoc );
        $pages = mcp_scaffold_pages();
        if ( is_wp_error( $pages ) ) { WP_CLI::error( $pages->get_error_message() ); }
        foreach ( $pages as $key => $page ) {
            WP_CLI::log( $key . ': ' . $page['id'] . ( $page['created'] ? ' created' : ' retained' ) );
            if ( $page['status'] !== 'publish' ) {
                WP_CLI::warning( $key . ' is ' . $page['status'] . ': review and publish it explicitly before checking public routes.' );
            }
        }
        if ( isset( $assoc['configure-reading'] ) ) {
            update_option( 'show_on_front', 'page' );
            update_option( 'page_on_front', $pages['home']['id'] );
            update_option( 'page_for_posts', 0 );
        }
        WP_CLI::success( 'Scaffold ready. Existing pages/content were retained.' );
    } );
}
