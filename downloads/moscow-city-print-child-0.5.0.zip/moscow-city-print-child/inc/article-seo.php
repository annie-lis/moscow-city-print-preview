<?php
/** Native article metadata, yielding to an installed SEO plugin. */
if ( ! defined( 'ABSPATH' ) ) { exit; }
function mcp_seo_plugin_active() {
    return defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'AIOSEO_VERSION' )
        || defined( 'SEOPRESS_VERSION' ) || defined( 'THE_SEO_FRAMEWORK_VERSION' );
}
function mcp_print_article_meta( $article, $canonical = false ) {
    if ( $canonical ) { echo '<link rel="canonical" href="' . esc_url( $article['url'] ) . '">' . "\n"; }
    $meta = array( 'description' => $article['description'], 'og:type' => 'article',
        'og:title' => $article['title'], 'og:description' => $article['description'],
        'og:url' => $article['url'], 'og:site_name' => $article['site_name'],
        'article:published_time' => $article['iso'] );
    if ( $article['modified'] !== $article['iso'] ) { $meta['article:modified_time'] = $article['modified']; }
    if ( ! empty( $article['image'] ) ) { $meta['og:image'] = $article['image']; }
    foreach ( $meta as $name => $value ) {
        echo '<meta ' . ( strpos( $name, ':' ) !== false ? 'property' : 'name' ) . '="' . esc_attr( $name ) . '" content="' . esc_attr( $value ) . '">' . "\n";
    }
    $posting = array( '@type' => 'BlogPosting', '@id' => $article['url'] . '#article',
        'mainEntityOfPage' => $article['url'], 'headline' => $article['title'],
        'description' => $article['description'], 'datePublished' => $article['iso'],
        'dateModified' => $article['modified'],
        'publisher' => array( '@type' => 'Organization', 'name' => $article['site_name'], 'url' => $article['home_url'] ) );
    if ( $article['author'] !== '' ) { $posting['author'] = array( '@type' => 'Person', 'name' => $article['author'] ); }
    if ( ! empty( $article['image'] ) ) { $posting['image'] = $article['image']; }
    $crumbs = array();
    foreach ( $article['breadcrumbs'] as $index => $crumb ) {
        $crumbs[] = array( '@type' => 'ListItem', 'position' => $index + 1, 'name' => $crumb['title'], 'item' => $crumb['url'] );
    }
    $schema = array( '@context' => 'https://schema.org', '@graph' => array( $posting,
        array( '@type' => 'BreadcrumbList', 'itemListElement' => $crumbs ) ) );
    echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>' . "\n";
}
function mcp_article_head() {
    if ( ! is_singular( 'post' ) || mcp_seo_plugin_active() ) { return; }
    mcp_print_article_meta( mcp_article_data( get_queried_object_id(), false ), ! has_action( 'wp_head', 'rel_canonical' ) );
}
add_action( 'wp_head', 'mcp_article_head', 5 );
function mcp_blog_robots( $robots ) {
    if ( mcp_current_route() === 'blog' && ! is_singular( 'post' ) ) {
        $state = mcp_blog_state();
        if ( $state['search'] !== '' || $state['category'] !== '' ) { $robots['noindex'] = true; unset( $robots['index'] ); }
    }
    return $robots;
}
add_filter( 'wp_robots', 'mcp_blog_robots' );
function mcp_blog_canonical( $url ) {
    return mcp_current_route() === 'blog' && ! is_singular( 'post' ) ? mcp_blog_link( mcp_blog_state() ) : $url;
}
add_filter( 'get_canonical_url', 'mcp_blog_canonical' );
function mcp_blog_title_parts( $parts ) {
    if ( mcp_current_route() === 'blog' && ! is_singular( 'post' ) ) {
        $parts['title'] = 'Блог';
        $state = mcp_blog_state();
        if ( $state['page'] > 1 ) { $parts['page'] = 'Страница ' . $state['page']; }
    }
    return $parts;
}
add_filter( 'document_title_parts', 'mcp_blog_title_parts' );
function mcp_blog_index_head() {
    if ( mcp_current_route() === 'blog' && ! is_singular( 'post' ) && is_home() && ! mcp_seo_plugin_active() ) {
        echo '<link rel="canonical" href="' . esc_url( mcp_blog_link( mcp_blog_state() ) ) . '">' . "\n";
    }
}
add_action( 'wp_head', 'mcp_blog_index_head', 5 );
