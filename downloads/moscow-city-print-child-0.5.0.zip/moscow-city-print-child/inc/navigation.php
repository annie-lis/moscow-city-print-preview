<?php
/** Native editable WP menu, rendered without introducing layout wrappers. */
if ( ! defined( 'ABSPATH' ) ) { exit; }
function mcp_primary_menu_items() {
    $items = array();
    if ( function_exists( 'get_nav_menu_locations' ) ) {
        $locations = get_nav_menu_locations();
        $menu_id = $locations['mcp-primary'] ?? get_option( 'mcp_primary_menu', 0 );
        $menu = $menu_id ? wp_get_nav_menu_items( $menu_id ) : array();
        foreach ( $menu ?: array() as $item ) {
            if ( (int) $item->menu_item_parent !== 0 ) { continue; }
            $contacts = $item->url === '#contacts' || trim( (string) parse_url( $item->url, PHP_URL_PATH ), '/' ) === 'contacts';
            $blog = untrailingslashit( $item->url ) === untrailingslashit( mcp_page_url( 'blog' ) );
            $items[] = array(
                'label' => $item->title,
                'url' => $contacts ? '#contacts' : $item->url,
                'current' => ! $contacts && ( ( $item->type === 'post_type' && (int) $item->object_id === get_queried_object_id() ) || ( $blog && mcp_current_route() === 'blog' ) ),
            );
        }
    }
    if ( $items ) { return $items; }
    foreach ( array( 'about' => 'О типографии', 'services' => 'Услуги', 'products' => 'Продукция', 'contacts' => 'Контакты' ) as $key => $label ) {
        $items[] = array( 'label' => $label, 'url' => mcp_page_url( $key ), 'current' => mcp_current_route() === $key );
    }
    return $items;
}
