<?php
/**
 * Template Name: MCP — Полезное о печати
 * Template Post Type: page
 * Catalog uses real WordPress Posts; no database configuration changes required.
 */
$catalog = $args['catalog'] ?? mcp_blog_data();
get_header();
?>
</section>
<main class="mcp-inner-main mcp-blog">
    <section class="mcp-inner-section mcp-inner-section--paper">
        <?php get_template_part( 'template-parts/components/section-marker', null, array( 'number' => '01', 'label' => 'БЛОГ' ) ); ?>
        <div class="mcp-inner-section-content mcp-blog-hero">
            <div><h1 class="mcp-page-title">БЛОГ</h1><p class="mcp-blog-subtitle">Объясняем печать простыми словами</p></div>
            <p class="mcp-blog-description">Материалы, макеты, технологии и&nbsp;производство — без&nbsp;сложных терминов.</p>
        </div>
    </section>
    <div class="mcp-blog-catalog">
        <?php get_template_part( 'template-parts/blog/catalog', null, $catalog ); ?>
    </div>
</main>
<?php get_footer( null, mcp_footer_args( array( array( 'number' => '01' ) ) ) ); ?>
