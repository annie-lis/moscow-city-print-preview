<?php
/**
 * Template Name: MCP — Полезное о печати
 * Template Post Type: page
 * Staging skeleton: no posts feed or invented sections at this stage.
 */
get_template_part( 'templates/internal' );
