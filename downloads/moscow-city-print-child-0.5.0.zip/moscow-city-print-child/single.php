<?php
/** Shared site shell, universal single-column article content. */
$article = $args['article'] ?? null;
if ( ! $article ) { while ( have_posts() ) { the_post(); $article = mcp_article_data( get_the_ID() ); break; } }
get_header();
?>
</section>
<main class="mcp-inner-main mcp-article-main">
<?php if ( $article ) { get_template_part( 'template-parts/blog/article', null, $article ); } ?>
</main>
<?php get_footer( null, mcp_footer_args( array() ) ); ?>
