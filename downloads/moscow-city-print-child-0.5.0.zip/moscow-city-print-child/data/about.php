<?php
/** Approved About structure; working copy, shared internal shell and original assets. */
$panel = static function ( $kind, $title, $text, $image = '', $alt = '', $heading = 'h2' ) {
    $copy = '<div class="mcp-about-copy"><' . $heading . ' class="mcp-page-title">' . esc_html( $title ) . '</' . $heading . '><p>' . esc_html( $text ) . '</p></div>';
    $media = $image ? '<img class="mcp-about-art" src="' . esc_url( mcp_asset_url( 'images/illustrations/' . $image ) ) . '" alt="' . esc_attr( $alt ) . '" loading="lazy" decoding="async">' : '';
    return '<div class="mcp-about-panel mcp-about-panel--' . $kind . '">' . $copy . $media . '</div>';
};
$sections = array(
    array( 'layout' => 'single', 'tone' => 'paper', 'number' => '01', 'label' => 'О ТИПОГРАФИИ',
        'content' => $panel( 'hero', 'Современная типография в сердце деловой Москвы', 'Moscow City Print — современная типография в ММДЦ «Москва-Сити». Работаем с 2014 года, а с 2016 года находимся в башне «Империя». Помогаем компаниям, брендам и агентствам воплощать идеи в качественную печатную продукцию.', '', '', 'h1' ) ),
    array( 'layout' => 'single', 'tone' => 'paper-alt', 'number' => '02', 'label' => 'НАШ ПОДХОД',
        'content' => $panel( 'approach', 'Современные технологии и внимание к каждой детали', 'Соединяем современные технологии печати и послепечатной обработки с вниманием к материалу, цвету и каждой детали. Консультируем, подбираем оптимальные решения и сопровождаем проект от идеи до готовой продукции.', 'mcp-illustration-print-production.webp', 'Печатное производство' ) ),
    array( 'layout' => 'single', 'tone' => 'paper', 'number' => '03', 'label' => 'НАША КОМАНДА',
        'content' => $panel( 'team', 'Люди, которые действительно разбираются в материале', 'В нашей команде — технологи, печатники, специалисты по постпечатной обработке, дизайнеры и менеджеры проектов. Мы ценим качество, соблюдаем сроки и подбираем решение под конкретную задачу клиента.', 'mcp-illustration-team-production.webp', 'Команда типографии за работой' ) ),
    array( 'layout' => 'single', 'tone' => 'paper-alt', 'number' => '04', 'label' => 'НАШЕ ПРОСТРАНСТВО',
        'content' => $panel( 'space', 'В центре деловой жизни Москвы', 'Типография находится в ММДЦ «Москва-Сити», в башне «Империя». Удобное расположение позволяет быстро решать задачи, оперативно согласовывать проекты и быть ближе к нашим клиентам.', 'mcp-illustration-moscow-city.webp', 'Панорама ММДЦ «Москва-Сити»' ) ),
    array( 'layout' => 'single', 'tone' => 'paper', 'number' => '05', 'label' => 'КЛИЕНТЫ И ПАРТНЁРЫ',
        'content' => $panel( 'clients', 'Бренды и компании, которые нам доверяют', 'Работаем с компаниями, корпоративными клиентами, малым и средним бизнесом, рекламными агентствами, дизайнерами и студиями, а также с культурными и образовательными проектами.' ) ),
);
$logos = '<div class="mcp-about-logos" aria-label="Клиенты">';
foreach ( array( 'Huawei', 'Братья Караваевы', 'R7', 'Empire', 'Торговый дом Пластик', 'АльфаХимПром', 'One Factor', 'TrendLaw' ) as $i => $name ) {
    $logos .= '<img class="client-logo" src="' . esc_url( mcp_asset_url( sprintf( 'images/clients/client-%02d.png', $i + 1 ) ) ) . '" alt="' . esc_attr( $name ) . '" loading="lazy" decoding="async">';
}
$sections[4]['content'] .= $logos . '</div>';
return $sections;
