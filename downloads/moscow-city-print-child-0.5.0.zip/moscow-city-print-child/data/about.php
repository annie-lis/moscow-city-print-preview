<?php
/** Approved editorial About composition, shared shell and original transparent assets. */
$panel = static function ( $kind, $title, $text, $image = '', $alt = '', $heading = 'h2', $aside = '' ) {
    $copy = '<div class="mcp-about-copy"><' . $heading . ' class="mcp-page-title">' . esc_html( $title ) . '</' . $heading . '><p>' . esc_html( $text ) . '</p></div>';
    $media = $image ? '<img class="mcp-about-art" src="' . esc_url( mcp_asset_url( 'images/illustrations/' . $image ) ) . '" alt="' . esc_attr( $alt ) . '" loading="lazy" decoding="async">' : '';
    return '<div class="mcp-about-panel mcp-about-panel--' . $kind . '">' . $copy . $media . $aside . '</div>';
};
$sections = array(
    array( 'layout' => 'hero', 'tone' => 'paper', 'heading' => 'h1',
        'title' => 'Типография для бизнеса',
        'content' => '<p>Moscow City Print — типография в ММДЦ «Москва-Сити». С 2014 года работаем с компаниями, брендами и агентствами, помогая воплощать идеи в печатную продукцию.</p>' ),
    array( 'layout' => 'single', 'tone' => 'paper-alt', 'number' => '01', 'label' => 'НАШ ПОДХОД',
        'content' => $panel( 'approach', 'Технологии, опыт и внимание к деталям', 'Соединяем современные технологии печати и постпечатной обработки с вниманием к каждой детали. Консультируем, подбираем оптимальные решения и сопровождаем проект на всех этапах — от идеи до готовой продукции.', 'mcp-illustration-print-production.webp', 'Печатное производство', 'h2', '<dl class="mcp-about-stats"><div><dt>10+</dt><dd>лет опыта в печати</dd></div><div><dt>10 000+</dt><dd>проектов разной сложности</dd></div><div><dt>50+</dt><dd>постоянных корпоративных клиентов</dd></div></dl>' ) ),
    array( 'layout' => 'single', 'tone' => 'paper', 'number' => '02', 'label' => 'НАША КОМАНДА',
        'content' => $panel( 'team', 'Люди, которые любят своё дело', 'В нашей команде — технологи, печатники, специалисты по постпечатной обработке, дизайнеры и менеджеры проектов, которые действительно разбираются в материале. Мы ценим качество, соблюдаем сроки и всегда ищем лучшее решение для задачи клиента.', 'mcp-illustration-team-production.webp', 'Команда типографии за работой', 'h2', '<ul class="mcp-about-principles"><li>Консультации и подбор материалов</li><li>Контроль качества на каждом этапе</li><li>Соблюдение сроков</li><li>Индивидуальный подход к каждому проекту</li></ul>' ) ),
    array( 'layout' => 'single', 'tone' => 'paper-alt', 'number' => '03', 'label' => 'НАШЕ ПРОСТРАНСТВО',
        'content' => $panel( 'space', 'В центре деловой жизни Москвы', 'Наша типография находится в ММДЦ «Москва-Сити», в башне «Империя» с 2016 года. Удобное расположение позволяет быстро решать задачи, оперативно согласовывать проекты и быть ближе к нашим клиентам.', 'mcp-illustration-moscow-city.webp', 'Панорама ММДЦ «Москва-Сити»' ) ),
    array( 'layout' => 'single', 'tone' => 'paper', 'number' => '04', 'label' => 'КЛИЕНТЫ И ПАРТНЁРЫ',
        'title' => 'Бренды и компании, которые нам доверяют',
        'content' => '<p>Работаем с компаниями, малым и средним бизнесом, рекламными агентствами, дизайнерами и студиями.</p>',
        'client_carousel' => true ),
);
return $sections;
