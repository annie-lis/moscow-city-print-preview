<?php
/** User-facing navigation in one section of the approved internal template. */
$content = '<div class="mcp-sitemap-grid">';
foreach ( mcp_sitemap_groups() as $group ) {
    $content .= '<div class="mcp-sitemap-group"><h2>' . esc_html( $group['title'] ) . '</h2>';
    foreach ( $group['items'] as $item ) {
        $content .= '<a href="' . esc_url( $item['url'] ) . '">' . esc_html( $item['title'] ) . '</a>';
    }
    $content .= '</div>';
}
$content .= '</div>';
return array(
    array(
        'layout' => 'single', 'tone' => 'paper', 'number' => '01',
        'label' => 'КАРТА САЙТА', 'content' => $content,
    ),
);
