<?php
/** WordPress retains its native 404 status; render with the common shell. */
$sections = array( array(
    'layout' => 'single', 'tone' => 'paper', 'number' => '01', 'label' => '404',
    'title' => 'Страница не найдена', 'heading' => 'h1',
    'content' => '<p>Возможно, ссылка устарела или страница была перемещена.</p>'
        . '<p><a href="' . esc_url( home_url( '/' ) ) . '">Вернуться на главную →</a></p>',
) );
get_header();
?>
</section>
<main class="mcp-inner-main">
<?php mcp_render_internal_sections( $sections ); ?>
</main>
<?php get_footer( null, mcp_footer_args( $sections ) ); ?>
