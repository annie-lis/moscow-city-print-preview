# Moscow City Print — рабочая дочерняя тема 0.4.2

Визуальная основа Главной: `54c52f4:work/main_hero_preview.html`.
Универсальный внутренний шаблон: принятая версия `238d43a`.
Общие стили, Geologica, grid, hero и crop marks сохранены.

Инструкция первого развёртывания на отдельном WordPress в
`modfox.com.ru/mcp-preview/`, маршруты, состояния страниц и дальнейшее
наполнение: **[DEPLOYMENT.md](DEPLOYMENT.md)**.

- Основа: `header.php` / `footer.php`, partials `template-parts/site/`.
- Главная: `front-page.php`, `template-parts/home/`.
- Все обычные внутренние страницы: `page.php` → `templates/internal.php`.
- Блог: `home.php` → `templates/blog.php`; запись: `single.php`.
- Ошибка: `404.php` с той же оболочкой, HTTP 404 от WordPress.
- Маршруты/приоритет контента/номер footer: `inc/routes.php`.
- Ручной bootstrap через WP-CLI: `inc/site-setup.php`; без записи в БД при активации.
- Общие стили: `assets/css/{tokens,site,page,internal}.css`.
- About — минимальный каркас, прежние экспериментальные секции не подключаются.
- Services — рабочая основа 01–05 из существующего reference в общей системе;
  карусель реальных работ и финальная композиция страницы потребуют отдельной задачи.

Схема внутренних секций: [INTERNAL_TEMPLATE.md](INTERNAL_TEMPLATE.md).
About: [ABOUT.md](ABOUT.md). Проверки: `tests/SITE_ARCHITECTURE_REPORT.md`
от корня репозитория. Полное дерево файлов сохранено в `FILE_TREE.txt`.

```sh
php tools/render-static.php work/static-site --sync-work
python3 tools/package-theme.py
```

ZIP устанавливается вместе с родительской **Twenty Twenty-One**.
PHP ≥8.0, WordPress ≥6.5. Генерируемый HTML не редактировать вручную.

Навигация 0.4.1: About → Services → Products → Contacts, логотип ведёт на Главную.
Пустые служебные заготовки: `payment-delivery`, `artwork-requirements`;
их нет в верхнем меню. Footer legal содержит policy → payment/delivery → requisites.
Текущая проверка навигации/геометрии: `tests/NAVIGATION_REPORT.md`.

## Реквизиты, версия 0.4.2

`/requisites/` использует `data/requisites.php` через существующий route provider
и общий `templates/internal.php`. Две single-секции: 01 «Реквизиты» (paper)
и 02 «Документы» (paper-alt), затем сразу общий footer без номера.
Юридические данные предоставлены пользователем: ИП Лис Анна Владимировна,
ИНН 772425521744, ОГРНИП 320774600200503. Рабочий контакт по документам:
`office@moscowcityprint.ru`, mailto. Внутри main нет дополнительного контактного
блока, телефона, Telegram, карты, изображений или CTA. Общий footer сохранён.
Страница не вводит CSS или отдельный шаблон. Явные данные редактора/meta
по-прежнему имеют приоритет; bootstrap существующий контент не перезаписывает.
