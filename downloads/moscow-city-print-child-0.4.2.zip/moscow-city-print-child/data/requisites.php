<?php
/** Approved legal details; rendered by the unchanged universal internal template. */
return array(
    array(
        'layout' => 'single', 'tone' => 'paper', 'number' => '01',
        'label' => 'РЕКВИЗИТЫ', 'title' => 'Реквизиты', 'heading' => 'h1',
        'content' => '<p>Индивидуальный предприниматель<br>Лис Анна Владимировна</p>'
            . '<p>ИНН<br>772425521744</p>'
            . '<p>ОГРНИП<br>320774600200503</p>',
    ),
    array(
        'layout' => 'single', 'tone' => 'paper-alt', 'number' => '02',
        'label' => 'ДОКУМЕНТЫ', 'title' => 'Документы',
        'content' => '<p>По вопросам закрывающих документов, актов, счетов и ЭДО напишите на '
            . '<a href="mailto:office@moscowcityprint.ru">office@moscowcityprint.ru</a>.</p>',
    ),
);
