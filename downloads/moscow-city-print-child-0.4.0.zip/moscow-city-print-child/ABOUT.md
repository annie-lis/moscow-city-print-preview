# About: минимальный каркас для первого развёртывания

Текущий `/about/` — нейтральная секция «О типографии» в принятом универсальном
шаблоне. Предыдущая плотная версия не является финальным контентным решением.
Она сохранена только в `tools/about-experimental-sections.php` и
`tools/about-experimental.css` вне устанавливаемой темы; автоматически не выводится.

- `data/about.php` — минимальные секции по умолчанию.
- `inc/routes.php` — включает их только у пустой страницы `/about/`.
- `page.php` / совместимый `templates/about.php` → `templates/internal.php`.
- Стили: общие `assets/css/{tokens,site,page,internal}.css`; отдельного About CSS нет.
- Редактор страницы и `_mcp_internal_sections` имеют приоритет над defaults.
- Footer общий и без номера по умолчанию, с сохранённым пустым слотом номера.

Подробнее: [DEPLOYMENT.md](DEPLOYMENT.md), [INTERNAL_TEMPLATE.md](INTERNAL_TEMPLATE.md).
