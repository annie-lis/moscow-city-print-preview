<?php
/** Canonical routes and page defaults. No database writes during theme activation. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function mcp_site_routes() {
    return array(
        'home' => array( 'slug' => '', 'title' => 'Главная' ),
        'about' => array( 'slug' => 'about', 'title' => 'О типографии' ),
        'services' => array( 'slug' => 'services', 'title' => 'Услуги' ),
        'products' => array( 'slug' => 'products', 'title' => 'Продукция' ),
        'blog' => array( 'slug' => 'blog', 'title' => 'Полезное о печати' ),
        'contacts' => array( 'slug' => 'contacts', 'title' => 'Контакты' ),
        'privacy-policy' => array( 'slug' => 'privacy-policy', 'title' => 'Политика конфиденциальности' ),
        'payment-delivery' => array( 'slug' => 'payment-delivery', 'title' => 'Оплата и доставка' ),
        'artwork-requirements' => array( 'slug' => 'artwork-requirements', 'title' => 'Требования к макетам' ),
        'requisites' => array( 'slug' => 'requisites', 'title' => 'Реквизиты' ),
        'sitemap' => array( 'slug' => 'sitemap', 'title' => 'Карта сайта' ),
        'vacancies' => array( 'slug' => 'vacancies', 'title' => 'Вакансии' ),
    );
}

function mcp_current_route() {
    if ( is_front_page() ) { return 'home'; }
    if ( is_home() || is_singular( 'post' ) ) { return 'blog'; }
    if ( is_page() ) {
        $slug = get_post_field( 'post_name', get_queried_object_id() );
        if ( isset( mcp_site_routes()[ $slug ] ) ) { return $slug; }
    }
    return '';
}

function mcp_nav_current( $slug ) {
    return mcp_current_route() === $slug ? ' aria-current="page"' : '';
}

/** Defaults only fill empty pages. Editor content and explicit section meta win. */
function mcp_route_sections( $sections, $post_id ) {
    if ( $sections || metadata_exists( 'post', $post_id, '_mcp_internal_sections' )
        || trim( (string) get_post_field( 'post_content', $post_id ) ) !== '' ) { return $sections; }
    $slug = get_post_field( 'post_name', $post_id );
    if ( $slug === 'about' ) { return require dirname( __DIR__ ) . '/data/about.php'; }
    if ( $slug === 'requisites' ) { return require dirname( __DIR__ ) . '/data/requisites.php'; }
    if ( $slug === 'payment-delivery' ) { return require dirname( __DIR__ ) . '/data/payment-delivery.php'; }
    if ( $slug === 'services' ) {
        return json_decode( file_get_contents( dirname( __DIR__ ) . '/data/services.json' ), true );
    }
    return $sections;
}
add_filter( 'mcp_internal_sections', 'mcp_route_sections', 10, 2 );

/** Internal footer is unnumbered by default; pages can explicitly opt into auto. */
function mcp_footer_args( $sections = array(), $mode = null ) {
    if ( $mode === null ) { $mode = get_post_meta( get_queried_object_id(), '_mcp_footer_numbering', true ); }
    $number = '';
    if ( $mode === 'auto' ) {
        $last = 0;
        foreach ( $sections as $section ) {
            foreach ( $section['columns'] ?? array( $section ) as $part ) {
                if ( isset( $part['number'] ) && is_numeric( $part['number'] ) ) {
                    $last = max( $last, (int) $part['number'] );
                }
            }
        }
        $number = sprintf( '%02d', $last + 1 );
    } elseif ( is_numeric( $mode ) && (int) $mode > 0 ) {
        $number = sprintf( '%02d', (int) $mode );
    }
    return apply_filters( 'mcp_footer_args', array( 'marker_number' => $number ), $sections );
}

function mcp_home_sections() {
    return array( 'products' => 'ПРОДУКЦИЯ', 'process' => 'ПРОЦЕСС', 'clients' => 'КЛИЕНТЫ' );
}
function mcp_home_section_number( $key ) {
    return sprintf( '%02d', array_search( $key, array_keys( mcp_home_sections() ), true ) + 1 );
}
