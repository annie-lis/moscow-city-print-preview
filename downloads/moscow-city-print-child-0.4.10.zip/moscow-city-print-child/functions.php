<?php
/** Shared site setup; the parent provides WordPress compatibility, not visual CSS. */
if ( ! defined( 'ABSPATH' ) ) { exit; }
require_once __DIR__ . '/inc/internal-sections.php';
require_once __DIR__ . '/inc/routes.php';
require_once __DIR__ . '/inc/site-setup.php';

function mcp_asset_url( $path ) {
    return get_stylesheet_directory_uri() . '/assets/' . ltrim( $path, '/' );
}
function mcp_page_url( $slug ) {
    $slug = trim( $slug, '/' );
    // Contacts live in the shared footer, never at a separate page URL.
    if ( $slug === 'contacts' ) { return '#contacts'; }
    $page = get_page_by_path( $slug );
    return $page ? get_permalink( $page ) : home_url( '/' . $slug . '/' );
}
function mcp_home_anchor( $anchor ) {
    return ( is_front_page() ? '' : home_url( '/' ) ) . '#' . $anchor;
}
function mcp_theme_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script' ) );
    // Parent layout CSS and editor palette must not override the accepted design.
    remove_theme_support( 'custom-background' );
    remove_theme_support( 'custom-header' );
    remove_theme_support( 'dark-editor-style' );
    remove_theme_support( 'custom-line-height' );
    remove_theme_support( 'custom-spacing' );
}
add_action( 'after_setup_theme', 'mcp_theme_setup', 20 );

function mcp_isolated_frontend() {
    remove_action( 'wp_enqueue_scripts', 'twenty_twenty_one_scripts' );
    remove_action( 'wp_enqueue_scripts', 'twenty_twenty_one_non_latin_languages' );
    remove_action( 'wp_print_footer_scripts', 'twenty_twenty_one_skip_link_focus_fix' );
    remove_action( 'wp_footer', 'twentytwentyone_add_ie_class' );
    remove_action( 'wp_enqueue_scripts', 'wp_enqueue_global_styles' );
    remove_action( 'wp_footer', 'wp_enqueue_global_styles', 1 );
    remove_action( 'wp_enqueue_scripts', 'wp_enqueue_classic_theme_styles' );
    remove_action( 'wp_head', 'wp_custom_css_cb', 101 );
}
add_action( 'after_setup_theme', 'mcp_isolated_frontend', 30 );

function mcp_enqueue_assets() {
    foreach ( array( 'twenty-twenty-one-custom-color-overrides', 'global-styles', 'classic-theme-styles', 'wp-block-library', 'wp-block-library-theme' ) as $handle ) {
        wp_dequeue_style( $handle );
    }
    $version = wp_get_theme()->get( 'Version' );
    wp_enqueue_style( 'mcp-fonts', 'https://fonts.googleapis.com/css2?family=Geologica:wght@300;400;500&display=swap', array(), null );
    wp_enqueue_style( 'mcp-tokens', mcp_asset_url( 'css/tokens.css' ), array( 'mcp-fonts' ), $version );
    wp_enqueue_style( 'mcp-site', mcp_asset_url( 'css/site.css' ), array( 'mcp-tokens' ), $version );
    if ( ! is_front_page() ) {
        wp_enqueue_style( 'mcp-page', mcp_asset_url( 'css/page.css' ), array( 'mcp-site' ), $version );
        wp_enqueue_style( 'mcp-internal', mcp_asset_url( 'css/internal.css' ), array( 'mcp-page' ), $version );
    }
    if ( mcp_current_route() === 'sitemap' ) {
        wp_enqueue_style( 'mcp-sitemap', mcp_asset_url( 'css/sitemap.css' ), array( 'mcp-internal' ), $version );
    }
    if ( mcp_current_route() === 'requisites' ) {
        wp_enqueue_style( 'mcp-requisites', mcp_asset_url( 'css/requisites.css' ), array( 'mcp-internal' ), $version );
    }
    if ( mcp_current_route() === 'payment-delivery' ) {
        wp_enqueue_style( 'mcp-payment-delivery', mcp_asset_url( 'css/payment-delivery.css' ), array( 'mcp-internal' ), $version );
    }
    if ( is_front_page() ) {
        wp_enqueue_script( 'mcp-home', mcp_asset_url( 'js/home.js' ), array(), $version, true );
    }
    wp_enqueue_script( 'mcp-site', mcp_asset_url( 'js/site.js' ), array(), $version, true );
}
add_action( 'wp_enqueue_scripts', 'mcp_enqueue_assets', 100 );
