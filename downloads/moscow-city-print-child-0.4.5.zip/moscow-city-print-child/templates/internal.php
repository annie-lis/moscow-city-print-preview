<?php
/**
 * Template Name: MCP — внутренняя страница
 * Template Post Type: page
 */
$sections = mcp_get_internal_sections( get_queried_object_id() );
get_header();
?>
  </section>
<main class="mcp-inner-main">
<?php if ( $sections ) : ?>
    <?php mcp_render_internal_sections( $sections ); ?>
<?php else : ?>
    <div class="mcp-inner-fallback">
        <?php get_template_part( 'template-parts/route-content' ); ?>
    </div>
<?php endif; ?>
</main>
<?php get_footer( null, mcp_footer_args( $sections ) ); ?>
