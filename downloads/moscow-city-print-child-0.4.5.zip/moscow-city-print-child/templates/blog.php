<?php
/**
 * Template Name: MCP — Полезное о печати
 * Template Post Type: page
 */
get_header();
?>
</section>
<main class="mcp-inner-main">
<?php
mcp_render_internal_sections( array( array(
    'layout' => 'single', 'tone' => 'paper', 'number' => '01',
    'label' => 'ПОЛЕЗНОЕ О ПЕЧАТИ', 'title' => 'Полезное о печати', 'heading' => 'h1',
) ) );
$posts_query = is_home() ? $GLOBALS['wp_query'] : new WP_Query( array(
    'post_type' => 'post', 'post_status' => 'publish',
    'paged' => max( 1, (int) get_query_var( 'paged' ), (int) get_query_var( 'page' ) ),
) );
while ( $posts_query->have_posts() ) {
    $posts_query->the_post();
    mcp_render_internal_sections( array( array(
        'layout' => 'single', 'tone' => 'paper-alt', 'title' => get_the_title(),
        'content' => '<p>' . esc_html( get_the_excerpt() ) . '</p><p><a href="' . esc_url( get_permalink() ) . '">Читать</a></p>',
    ) ) );
}
$pagination = paginate_links( array( 'total' => $posts_query->max_num_pages, 'current' => max( 1, (int) get_query_var( 'paged' ), (int) get_query_var( 'page' ) ) ) );
if ( $pagination ) {
    mcp_render_internal_sections( array( array( 'layout' => 'single', 'tone' => 'paper', 'content' => $pagination ) ) );
}
wp_reset_postdata();
?>
</main>
<?php get_footer( null, mcp_footer_args( array( array( 'number' => '01' ) ) ) ); ?>
