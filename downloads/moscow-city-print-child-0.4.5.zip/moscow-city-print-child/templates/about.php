<?php
/**
 * Template Name: MCP — О типографии
 * Template Post Type: page
 */
// Reuse the approved internal shell; no About-specific header or footer.
get_template_part( 'templates/internal' );
