<?php
/** WordPress posts index, including a configured /blog/ posts page. */
get_template_part( 'templates/blog' );
