<?php
/** Articles use the same internal workspace and title/content component. */
get_template_part( 'templates/internal' );
