<?php while ( have_posts() ) : the_post(); ?>
<article class="mcp-page-content">
  <h1 class="mcp-page-title"><?php the_title(); ?></h1>
  <div class="mcp-page-copy"><?php the_content(); ?></div>
</article>
<?php endwhile; ?>
