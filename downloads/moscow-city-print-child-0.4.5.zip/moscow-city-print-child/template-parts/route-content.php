<?php
/** Editor content always wins; only empty functional routes have built-in output. */
while ( have_posts() ) : the_post(); ?>
<article class="mcp-page-content">
  <h1 class="mcp-page-title"><?php the_title(); ?></h1>
  <div class="mcp-page-copy">
  <?php
  if ( trim( (string) get_post_field( 'post_content', get_queried_object_id() ) ) !== '' ) {
      the_content();
  } elseif ( mcp_current_route() === 'contacts' ) {
      echo '<div class="footer-contact">';
      get_template_part( 'template-parts/components/contact-details' );
      echo '</div>';
  } elseif ( mcp_current_route() === 'sitemap' ) {
      echo '<ul>';
      foreach ( mcp_site_routes() as $key => $route ) {
          echo '<li><a href="' . esc_url( $key === 'home' ? home_url( '/' ) : mcp_page_url( $route['slug'] ) ) . '">' . esc_html( $route['title'] ) . '</a></li>';
      }
      echo '</ul>';
  }
  ?>
  </div>
</article>
<?php endwhile; ?>
