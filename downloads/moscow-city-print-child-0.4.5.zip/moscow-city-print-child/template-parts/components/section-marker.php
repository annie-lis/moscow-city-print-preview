<?php
/** Reusable marker. Caller supplies its existing number and label. */
$number = isset( $args['number'] ) ? $args['number'] : '';
$label = isset( $args['label'] ) ? $args['label'] : '';
?>
<div class="section-marker"><span class="num"><?php echo esc_html( $number ); ?></span><span class="rule"></span><span class="label"><?php echo esc_html( $label ); ?></span></div>
