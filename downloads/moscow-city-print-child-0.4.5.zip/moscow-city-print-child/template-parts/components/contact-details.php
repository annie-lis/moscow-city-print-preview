          <div class="footer-contact-row">
            <div class="footer-label">Почта</div>
            <div class="footer-value"><a href="mailto:hello@moscowcityprint.ru">hello@moscowcityprint.ru</a></div>
          </div>
          <div class="footer-contact-row">
            <div class="footer-label">Телефон</div>
            <div class="footer-value"><a href="tel:+74993911544">+7 (499) 391-15-44</a></div>
          </div>
          <div class="footer-contact-row">
            <div class="footer-label">График</div>
            <div class="footer-value">Пн–Пт, 10:00–19:00</div>
          </div>
          <div class="footer-contact-row">
            <div class="footer-label">Адрес</div>
            <div class="footer-value">Москва, Пресненская наб. 6с2,<br>башня «Империя», ММДЦ «Москва-Сити»</div>
          </div>
