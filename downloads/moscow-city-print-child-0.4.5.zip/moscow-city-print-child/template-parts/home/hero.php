    <section class="hero" aria-label="Печатаем то, что представляет ваш бизнес">
      <img class="hero-banner" src="<?php echo esc_url( mcp_asset_url( 'images/banner_hero.png' ) ); ?>" width="6668" height="1668" alt="Печатаем то, что представляет ваш бизнес. Современная типография в Москва-Сити. Полный цикл печати и постпечатной обработки для компаний и агентств." decoding="async">
    </section>
