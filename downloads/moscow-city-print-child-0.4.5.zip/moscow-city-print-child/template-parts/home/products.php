  <section class="band band-2">
    <?php get_template_part( 'template-parts/components/section-marker', null, array( 'number' => mcp_home_section_number( 'products' ), 'label' => 'ПРОДУКЦИЯ' ) ); ?>
    <div class="section02-inner">
      <div class="section02-intro">
        <h2 class="section02-title">Наш<br>профиль</h2>
      </div>
      <div class="services">
        <article class="service">
          <div class="service-num">01</div>
          <div class="card-content">
            <h3>Корпоративная<br>полиграфия</h3>
            <p>Для&nbsp;ежедневных и&nbsp;представительских задач бизнеса.</p>
          </div>
          <div class="service-arrow">→</div>
        </article>
        <article class="service">
          <div class="service-num">02</div>
          <div class="card-content">
            <h3>Премиум-полиграфия</h3>
            <p>Когда материал становится частью впечатления о&nbsp;бренде.</p>
          </div>
          <div class="service-arrow">→</div>
        </article>
        <article class="service">
          <div class="service-num">03</div>
          <div class="card-content">
            <h3>Упаковочная<br>продукция</h3>
            <p>Физическое продолжение визуального образа бренда.</p>
          </div>
          <div class="service-arrow">→</div>
        </article>
        <article class="service">
          <div class="service-num">04</div>
          <div class="card-content">
            <h3>Брендированная<br>продукция</h3>
            <p>Фирменные материалы, которые остаются с&nbsp;клиентом.</p>
          </div>
          <div class="service-arrow">→</div>
        </article>
      </div>
    </div>
  </section>
