  <section class="band band-3">
    <?php get_template_part( 'template-parts/components/section-marker', null, array( 'number' => mcp_home_section_number( 'process' ), 'label' => 'ПРОЦЕСС' ) ); ?>
    <div class="section03-inner">
      <div class="section03-intro">
        <h2 class="section03-title">От задачи<br>до тиража</h2>
      </div>
      <div class="steps">
        <article class="step">
          <div class="step-num">01</div>
          <div class="card-content">
            <h3>Задача</h3>
            <p>Расскажите, что нужно изготовить, в&nbsp;каком количестве и&nbsp;к&nbsp;какому сроку.</p>
          </div>
        </article>
        <article class="step">
          <div class="step-num">02</div>
          <div class="card-content">
            <h3>Согласование</h3>
            <p>Проверяем макет, уточняем детали и&nbsp;согласовываем материалы, отделку и&nbsp;параметры заказа.</p>
          </div>
        </article>
        <article class="step">
          <div class="step-num">03</div>
          <div class="card-content">
            <h3>Производство</h3>
            <p>Запускаем тираж и&nbsp;контролируем качество на&nbsp;каждом этапе производства.</p>
          </div>
        </article>
        <article class="step">
          <div class="step-num">04</div>
          <div class="card-content">
            <h3>Готовность</h3>
            <p>Передаём готовый заказ в&nbsp;согласованный срок.</p>
          </div>
        </article>
      </div>
    </div>
  </section>
