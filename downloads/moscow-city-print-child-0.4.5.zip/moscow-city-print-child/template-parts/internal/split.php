<section class="mcp-inner-section mcp-inner-section--split mcp-inner-section--<?php echo esc_attr( $args['tone'] ); ?>">
    <div class="mcp-inner-split">
        <?php foreach ( $args['columns'] as $column ) : ?>
        <div class="mcp-inner-column">
            <?php get_template_part( 'template-parts/components/section-marker', null, $column ); ?>
            <div class="mcp-inner-column-content">
                <?php get_template_part( 'template-parts/internal/content', null, $column ); ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</section>
