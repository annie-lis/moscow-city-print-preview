<section class="mcp-inner-section mcp-inner-section--wide mcp-inner-section--<?php echo esc_attr( $args['tone'] ); ?>">
    <?php get_template_part( 'template-parts/components/section-marker', null, $args ); ?>
    <div class="mcp-inner-section-content">
        <?php get_template_part( 'template-parts/internal/content', null, $args ); ?>
    </div>
</section>
