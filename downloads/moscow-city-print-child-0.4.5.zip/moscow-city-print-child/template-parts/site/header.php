    <header class="header">
      <a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="Moscow City Print — Главная"><img src="<?php echo esc_url( mcp_asset_url( 'images/logo.png' ) ); ?>" alt="Типография Москва Сити Принт"></a>
      <div class="header-right">
        <div class="status"><span>12:04</span><span>·</span><span>Работаем</span></div>
        <nav class="nav">
          <a href="<?php echo esc_url( mcp_page_url( 'about' ) ); ?>"<?php echo mcp_nav_current( 'about' ); ?>>О&nbsp;типографии</a>
          <a href="<?php echo esc_url( mcp_page_url( 'services' ) ); ?>"<?php echo mcp_nav_current( 'services' ); ?>>Услуги</a>
          <a href="<?php echo esc_url( mcp_page_url( 'products' ) ); ?>"<?php echo mcp_nav_current( 'products' ); ?>>Продукция</a>
          <a href="<?php echo esc_url( mcp_page_url( 'contacts' ) ); ?>"<?php echo mcp_nav_current( 'contacts' ); ?>>Контакты</a>
        </nav>
      </div>
    </header>
