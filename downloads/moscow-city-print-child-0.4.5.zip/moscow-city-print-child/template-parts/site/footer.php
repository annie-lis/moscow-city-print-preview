<?php
// Also support callers that render the common footer without passing a number.
$marker_number = $args['marker_number'] ?? '';
if ( $marker_number === '' ) {
    $marker_number = mcp_footer_args( mcp_get_internal_sections( get_queried_object_id() ) )['marker_number'];
}
?>
  <footer class="band band-5" id="contacts">
    <?php get_template_part( 'template-parts/components/section-marker', null, array( 'number' => $marker_number, 'label' => 'КОНТАКТЫ' ) ); ?>
    <div class="footer-inner">
      <div class="footer-intro">
        <h2 class="footer-title">Обсудить<br>проект</h2>
      </div>

      <div class="footer-main">
        <div class="footer-contact">
<?php get_template_part( 'template-parts/components/contact-details' ); ?>
        </div>

        <div class="footer-actions">
          <a class="footer-action" href="mailto:hello@moscowcityprint.ru?subject=%D0%97%D0%B0%D0%BF%D1%80%D0%BE%D1%81%20%D0%BD%D0%B0%20%D1%80%D0%B0%D1%81%D1%87%D1%91%D1%82">
            <span>Отправить письмо</span><span class="footer-action-arrow">→</span>
          </a>
          <a class="footer-action" href="https://t.me/moscowcityprint" target="_blank" rel="noopener">
            <span>Написать в&nbsp;Telegram</span><span class="footer-action-arrow">→</span>
          </a>
          <a class="footer-action" href="https://yandex.ru/profile/1799094691?lang=ru&amp;utm_source=copy_link&amp;utm_medium=social&amp;utm_campaign=share" target="_blank" rel="noopener">
            <span>Открыть в&nbsp;Я.Картах</span><span class="footer-action-arrow">→</span>
          </a>
        </div>
      </div>
    </div>

    <div class="footer-legal">
      <div class="footer-legal-left">
        <span>© 2014–2026</span><span>·</span>
        <span>Типография «Moscow City Print»</span><span>·</span>
        <span>Все права защищены</span><span>·</span>
        <a href="<?php echo esc_url( mcp_page_url( 'privacy-policy' ) ); ?>">Политика конфиденциальности</a><span>·</span>
        <a href="<?php echo esc_url( mcp_page_url( 'payment-delivery' ) ); ?>">Оплата и доставка</a><span>·</span>
        <a href="<?php echo esc_url( mcp_page_url( 'requisites' ) ); ?>">Реквизиты</a>
      </div>
      <div>Разработка сайта — <a href="https://madfox.agency/" target="_blank" rel="noopener">Madfox</a></div>
    </div>
  </footer>
