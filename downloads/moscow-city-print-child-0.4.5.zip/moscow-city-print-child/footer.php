<?php get_template_part( 'template-parts/site/footer', null, $args ?? array() ); ?>
<?php get_template_part( 'template-parts/site/crop-marks' ); ?>
</div>
<?php wp_footer(); ?>
</body>
</html>
