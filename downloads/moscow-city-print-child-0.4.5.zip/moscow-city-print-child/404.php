<?php
/** WordPress retains its native 404 status; render with the common shell. */
get_header();
?>
</section>
<main class="mcp-inner-main">
<?php mcp_render_internal_sections( array( array(
    'layout' => 'single', 'tone' => 'paper', 'label' => '404',
    'title' => 'Страница не найдена', 'heading' => 'h1',
    'content' => '<p><a href="' . esc_url( home_url( '/' ) ) . '">На главную</a></p>',
) ) ); ?>
</main>
<?php get_footer( null, mcp_footer_args() ); ?>
