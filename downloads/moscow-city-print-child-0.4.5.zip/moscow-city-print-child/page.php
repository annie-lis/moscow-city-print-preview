<?php
/** Every ordinary page uses the approved, data-driven internal shell. */
get_template_part( 'templates/internal' );
