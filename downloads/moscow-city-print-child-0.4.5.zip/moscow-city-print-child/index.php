<?php
/** Safe fallback using the same shell; adds no new copy. */
get_template_part( 'page' );
