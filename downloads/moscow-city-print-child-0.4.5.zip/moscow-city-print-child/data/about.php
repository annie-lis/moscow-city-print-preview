<?php
/** Minimal About scaffold. Experimental composition is deliberately not loaded. */
return array( array(
    'layout' => 'single', 'tone' => 'paper', 'number' => '01',
    'label' => 'О ТИПОГРАФИИ', 'title' => 'О типографии', 'heading' => 'h1',
) );
