<?php
/** Approved legal details; rendered by the unchanged universal internal template. */
return array(
    array(
        'layout' => 'single', 'tone' => 'paper', 'number' => '01',
        'label' => 'РЕКВИЗИТЫ',
        'content' => '<dl class="mcp-requisites-details">'
            . '<div><dt>Индивидуальный предприниматель</dt><dd>Лис Анна Владимировна</dd></div>'
            . '<div><dt>ИНН</dt><dd>772425521744</dd></div>'
            . '<div><dt>ОГРНИП</dt><dd>320774600200503</dd></div>'
            . '</dl>',
    ),
    array(
        'layout' => 'single', 'tone' => 'paper-alt', 'number' => '02',
        'label' => 'ДОКУМЕНТЫ',
        'content' => '<p>По вопросам закрывающих документов, актов, счетов и ЭДО — '
            . '<a href="mailto:office@moscowcityprint.ru">office@moscowcityprint.ru</a></p>'
            . '<p>Подготовка документов обычно занимает от 1 до 5 рабочих дней.</p>',
    ),
);
