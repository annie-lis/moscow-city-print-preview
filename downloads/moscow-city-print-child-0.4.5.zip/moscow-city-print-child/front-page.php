<?php
/** Accepted Home, assembled from the shared site shell. */
get_header();
get_template_part( 'template-parts/home/hero' );
?>
  </section>
<?php
get_template_part( 'template-parts/home/products' );
get_template_part( 'template-parts/home/process' );
get_template_part( 'template-parts/home/clients' );
get_footer( null, mcp_footer_args( array_map( function ( $key ) { return array( 'number' => mcp_home_section_number( $key ) ); }, array_keys( mcp_home_sections() ) ), 'auto' ) );
